﻿namespace Presentation.Model
{
    public class CalculationRequest
    {
        public string Input1 { get; set; }
        public string Input2 { get; set; }
        public string Operation { get; set; }
    }
}
