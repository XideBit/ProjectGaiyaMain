﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Factory
{
    public enum OperationType
    {
        Plus=1,
        Minus=2,
        Multiply=3,
        Divide=4
    }
}
